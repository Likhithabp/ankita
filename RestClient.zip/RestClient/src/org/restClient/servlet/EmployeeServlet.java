package org.restClient.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;

import org.restClient.model.Employee;

public class EmployeeServlet extends HttpServlet {
	
	private Client client;

	public void init(ServletConfig config) throws ServletException {
		this.client = ClientBuilder.newClient();
	}
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)  
            throws ServletException, IOException {  
		System.out.println("Inside Get");
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)  
            throws ServletException, IOException {  
		
		List<Employee> employees = new ArrayList<Employee>();

		String actionType = request.getParameter("actionType");
		
		if(null != actionType && actionType.equals("insertEmp")) {
			
		      Form form = new Form();
		      form.param("empNo", request.getParameter("empNo"));
		      form.param("empName", request.getParameter("empName"));
		      form.param("position", request.getParameter("position"));

		      Employee employee = client
		         .target("http://localhost:8080/RestTest/rest/employees")
		         .request(MediaType.APPLICATION_XML)
		         .post(Entity.entity(form,
		            MediaType.APPLICATION_FORM_URLENCODED_TYPE),
		            Employee.class);
		      
		      employees.add(employee);
			
		} else if(null != actionType && actionType.equals("updateEmp")) {
			
		      Form form = new Form();
		      form.param("empNo", request.getParameter("empNo"));
		      form.param("empName", request.getParameter("empName"));
		      form.param("position", request.getParameter("position"));

		      Employee employee = client
		         .target("http://localhost:8080/RestTest/rest/employees")
		         .request(MediaType.APPLICATION_XML)
		         .put(Entity.entity(form,
		            MediaType.APPLICATION_FORM_URLENCODED_TYPE),
		            Employee.class);
		      
		      employees.add(employee);
			
		} else if(null != actionType && actionType.equals("retrieveEmp")) {

		      Employee employee = client
		         .target("http://localhost:8080/RestTest/rest/employees")
		    	         .path("/{empNo}")
		    	         .resolveTemplate("empNo", request.getParameter("empNo"))
		    	         .request(MediaType.APPLICATION_XML)
		    	         .get(Employee.class);
		      
		      employees.add(employee);
			
		} else if(null != actionType && actionType.equals("deleteEmp")) {

		      Employee employee = client
		         .target("http://localhost:8080/RestTest/rest/employees")
		    	         .path("/{empNo}")
		    	         .resolveTemplate("empNo", request.getParameter("empNo"))
		    	         .request(MediaType.APPLICATION_XML)
		    	         .delete(Employee.class);
		      
		      employees.add(employee);
			
		} else if(null != actionType && actionType.equals("retrieveAllEmps")) {

			GenericType<List<Employee>> list = new GenericType<List<Employee>>() {};
			
		    employees = client
		         .target("http://localhost:8080/RestTest/rest/employees")
		    	         .request(MediaType.APPLICATION_XML)
		    	         .get(list);
			
		} 
		
		request.setAttribute("employeesList", employees);

        RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/employeeResults.jsp");
        dispatcher.forward(request, response);
		
	}
}
